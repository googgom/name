int minf(int A[],int n);
