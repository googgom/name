int maxf( int A[], int n );
