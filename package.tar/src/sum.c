#include "sum.h"
#include "min.h"
int sumf( int A[], int n ){
  int minv = minf( A, n );
  int ans = 0;
  for( int i = 0; i < n; ++ i ){
    //ans += A[i];
    if( A[i] == minv ) break; else ans += A[i];
  }
  return ans;
}
