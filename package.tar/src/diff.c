#include "diff.h"
#include "min.h"
#include "max.h"
int diff( int A[], int n ){
  int maxv = maxf( A, n );
  int minv = minf( A, n );
  return maxv - minv;
}
