int sumf(int A[], int n);
