#include <stdio.h>
#include "min.h"
#include "max.h"
#include "diff.h"
#include "sum.h"

int main( int argv, char **argc ){
  int val = 0, array_size = 0, flag = 0;
  int Array[102];
  scanf("%d",&val);
  //printf("%d",val);
  //if( array_size <= 0 ) flag = 1;
  if( val < 0 ) flag = 2;
  if( val > 3 ) flag = 3;

     char current_char = '0';
     int value = 0;
     int breaker = 0;

     while( 1 ){///Ни чем не отличается от do{}while(); - просто лучше.
          scanf("%c", &current_char);
//      	  if( array_size >= 101 ) continue;
          if( current_char == '\n' ){
               Array[array_size++] = value;//Последний элемент
               break;
          }
          if( current_char == ' ' ){
               if( breaker == 1 )
                    Array[array_size++] = value, value = 0;
          }else{

               breaker = 1;
               value *= 10;
               value += current_char;
               value -= '0';
          }
     }
  //printf("%d\n", array_size);
  if( array_size > 100 ) flag = 4;
  if( flag != 0 ){
    puts("Данные некорректны\n");
    if( argc[1] == "debug" ) printf( "%d", flag );
    return 0;
  }
  int ans = 0;
  if( val == 0 ) ans = maxf( Array, array_size );
  if( val == 1 ) ans = minf( Array, array_size );
  if( val == 2 ) ans = diff( Array, array_size );
  if( val == 3 ) ans = sumf( Array, array_size );
  printf("%d\n", ans);
  return 0;
}
