int diff(int A[], int n);
